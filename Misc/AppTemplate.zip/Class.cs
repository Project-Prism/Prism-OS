﻿using PrismOS.Libraries.Graphics;
using PrismOS.Libraries.Graphics.GUI;

namespace $rootnamespace$
{
    public class $safeitemrootname$ : Runtime.Application
    {
        public Window Window = new();

        public override void OnCreate()
        {
            // Main window
            Window.Position = new(256, 256);
            Window.Size = new(400, 175);
            Window.Theme = Theme.DefaultDark;
            Window.Text = "Form1";

            Runtime.Windows.Add(Window);
        }

        public override void OnDestroy()
        {
            
        }

        public override void OnUpdate()
        {

        }
    }
}