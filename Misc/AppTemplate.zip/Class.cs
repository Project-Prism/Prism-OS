﻿using PrismOS.Libraries;
using PrismOS.Libraries.Graphics;
using PrismOS.Libraries.Graphics.GUI;

namespace $rootnamespace$
{
    public class $safeitemrootname$ : Runtime.Application
    {
        public Window Window;
	
        public override void OnCreate()
        {
            // Main window
            Window.X = 256;
            Window.Y = 256;
            Window.Width = 400;
            Window.Height = 175;
            Window.Radius = 0;
            Window.Theme = Theme.DefaultDark;
            Window.Text = "GUI_AppTemplate1";

            Runtime.Windows.Add(Window);
        }

        public override void OnDestroy()
        {
            
        }

        public override void OnUpdate()
        {
            
        }
    }
}